package me.dio.claro_springboot_2024;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaroSpringboot2024ApplicationTests {

	@Test
	void contextLoads() {
	}

}
