package me.dio.claro_springboot_2024.repositery;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import me.dio.claro_springboot_2024.model.User;

@Repository
public interface UserRepositery extends JpaRepository<User, Long> {
	
	public boolean existsByAccountNumber(String accountNumberString);

}
