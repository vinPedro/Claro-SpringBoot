package me.dio.claro_springboot_2024.model;

import jakarta.persistence.*;

import java.math.BigDecimal;

@Entity(name = "TB_CARD")
public class Card {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idLong;

    @Column(unique = true)
    private String numberString;

    @Column(precision = 13, scale = 2)
    private BigDecimal limitBigDecimal;

    public Long getId() {
        return idLong;
    }

    public void setId(Long id) {
        this.idLong = id;
    }

    public String getNumber() {
        return numberString;
    }

    public void setNumber(String number) {
        this.numberString = number;
    }

    public BigDecimal getLimit() {
        return limitBigDecimal;
    }

    public void setLimit(BigDecimal limit) {
        this.limitBigDecimal = limit;
    }

}
