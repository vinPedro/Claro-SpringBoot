package me.dio.claro_springboot_2024.service.imp;

import java.util.NoSuchElementException;

import org.springframework.stereotype.Service;

import me.dio.claro_springboot_2024.model.User;
import me.dio.claro_springboot_2024.repositery.UserRepositery;
import me.dio.claro_springboot_2024.service.UserService;

@Service
public class UserServiceImp implements UserService{
	
	private final UserRepositery userRepositery;
	
	public UserServiceImp(UserRepositery userRepositery) {
		this.userRepositery = userRepositery;
		
	}

	@Override
	public User findById(Long idLong) {
		return userRepositery.findById(idLong).orElseThrow(NoSuchElementException::new);
	}

	@Override
	public User create(User userToCreate) {
		if (userRepositery.existsByAccountNumber(userToCreate.getAccount().getNumber())) {
			throw new IllegalArgumentException("This Account number already exists.");
		}
		
		return userRepositery.save(userToCreate);
	}

}
