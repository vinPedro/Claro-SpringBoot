package me.dio.claro_springboot_2024.service;

import me.dio.claro_springboot_2024.model.User;

public interface UserService {

	public User findById(Long idLong);
	
	public User create(User userToCreate);
}
