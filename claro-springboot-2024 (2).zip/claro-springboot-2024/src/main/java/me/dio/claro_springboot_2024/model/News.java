package me.dio.claro_springboot_2024.model;

import jakarta.persistence.Entity;

@Entity(name = "TB_NEWS")
public class News extends BaseItem {

}
