package me.dio.claro_springboot_2024.model;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class BaseItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idLong;
    
    private String iconString;

    private String descriptionString;

    public Long getId() {
        return idLong;
    }

    public void setId(Long id) {
        this.idLong = id;
    }

    public String getIcon() {
        return iconString;
    }

    public void setIcon(String icon) {
        this.iconString = icon;
    }

    public String getDescription() {
        return descriptionString;
    }

    public void setDescription(String description) {
        this.descriptionString = description;
    }

}
