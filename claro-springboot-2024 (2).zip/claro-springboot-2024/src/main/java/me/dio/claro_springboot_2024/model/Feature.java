package me.dio.claro_springboot_2024.model;

import jakarta.persistence.Entity;

@Entity(name = "TB_FEATURE")
public class Feature extends BaseItem {

}
