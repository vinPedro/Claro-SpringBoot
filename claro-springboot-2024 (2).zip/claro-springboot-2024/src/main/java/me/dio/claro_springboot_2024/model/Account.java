package me.dio.claro_springboot_2024.model;

import jakarta.persistence.*;

import java.math.BigDecimal;

@Entity(name = "TB_ACCOUNT")
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idLong;

    @Column(unique = true)
    private String numberString;

    private String agency;

    @Column(precision = 13, scale = 2)
    private BigDecimal balanceBigDecimal;

    @Column( precision = 13, scale = 2)
    private BigDecimal limitBigDecimal;

    public Long getId() {
        return idLong;
    }

    public void setId(Long id) {
        this.idLong = id;
    }

    public String getNumber() {
        return numberString;
    }

    public void setNumber(String number) {
        this.numberString = number;
    }

    public String getAgency() {
        return agency;
    }

    public void setAgency(String agency) {
        this.agency = agency;
    }

    public BigDecimal getBalance() {
        return balanceBigDecimal;
    }

    public void setBalance(BigDecimal balance) {
        this.balanceBigDecimal = balance;
    }

    public BigDecimal getLimit() {
        return limitBigDecimal;
    }

    public void setLimit(BigDecimal limit) {
        this.limitBigDecimal = limit;
    }

}
